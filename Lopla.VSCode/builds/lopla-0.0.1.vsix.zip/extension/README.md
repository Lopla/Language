# lopla README

Plugin for handling lopla language grammar within vs code ide. http://lopla.info

## Features

* Supports keywords highlight.
* Checks for availble library functions within base language scope (using intellisense ctrl+space)

## Release Notes

### 0.0.1

Initial release of lopla langugae plugin

